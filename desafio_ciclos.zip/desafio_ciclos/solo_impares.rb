#desafio 4

#Crea un programa llamado solo_impares.rb que dado n muestre en pantalla los primeros n números impares

n = ARGV[0].to_i
n_impares = 0
i = 0

until n_impares == n do
    if i%2 != 0
        print "#{i} "
        n_impares +=1
    end
    i+=1
end
print "\n"