#desafio 8

#Se  busca  crear un  programa fuerza_bruta.rb  que  revise cuantos intentos requiere hackear unpassword por fuerza bruta

#intento 1

# def gen2(pass)

#     letters = ('a'..'z').to_a
#     initial_code =""

#     (pass.size).times do
#         initial_code += letters[rand(letters.size)].to_s
#     end

#     return initial_code
# end

#intento 2
def gen(pass)

    initial_code = ""
    letter = "a"

    (pass.size).times do
        initial_code += letter
        letter = letter.next
    end

    return initial_code
end

pass= ARGV[0]
decoded = gen(pass)

count = 0
until (decoded == pass) do
    count +=1
    decoded = decoded.next
end

puts ("#{count} intentos")
 






