#desafio 1
#cambiar while por times

# i = 0
# while i < 50
#     puts "Iteración #{i}"
#     i = i + 1
# end

50.times do |i|
    puts "Iteración #{i}"
end