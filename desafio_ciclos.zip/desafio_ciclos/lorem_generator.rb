#desafio 6

#Crear un programa llamado lorem_generator.rb en ruby que sea capaz de mostrarn en pantalla
#varios parrafos de Lorem ipsum, donde el número de párrafos se especifica al cargar el script. 
#(El texto puede ser extraído del primer párrafo de (https://www.lipsum.com/feed/html

p_num = ARGV[0].to_i

p_num.times do |i|
    print ("#{i} Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pulvinar vulputate ex. Integer aliquet ligula ex, at accumsan massa porttitor ut. Morbi velit tellus, feugiat eu porta quis, tincidunt at dui. Sed ex ante, rhoncus vitae nunc a, sollicitudin vulputate urna. Nunc tincidunt blandit tortor quis sollicitudin. Sed ut augue libero. Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed sit amet auctor nisl. Pellentesque sed ligula faucibus, consectetur justo in, viverra ipsum. Sed consectetur consectetur leo, ut imperdiet justo dignissim sed. Ut id vehicula mi. Integer molestie cursus ex non ultrices. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Integer ut massa rutrum, eleifend tortor at, dapibus nisi. Morbi odio nunc, aliquam in ante id, viverra ullamcorper elit.\n\n")
end