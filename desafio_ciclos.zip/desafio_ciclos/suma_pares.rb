#desafio 5
# Crea un programa llamado suma_pares.rb que sume los primeros n números pares, donde n esingresado por el usuario por linea de comandos

n = ARGV[0].to_i
n_even_sum = 0
n_even_count = 1
i = 1

while (n_even_count <= n) do
    if (i%2==0)
        n_even_sum += i
        n_even_count +=1
        print "#{i}, #{n_even_sum} \n"
        i+=1
     
    else
        i+=1
    end
end

puts (n_even_sum)

