#desafio 3.b
#mostrar los primeros n numeros pares, con n ingresado del usuario, sin considerar el 0

n = ARGV[0].to_i
n_pares = 0
i = 0

until n_pares == n do
    if i%2 == 0 && i != 0
        print "#{i} "
        n_pares +=1
    end
    i+=1
end
print "\n"