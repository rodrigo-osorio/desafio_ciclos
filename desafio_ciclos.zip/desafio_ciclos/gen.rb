#desafio 7

#Sabiendo que "a.next"  =>  b  y "b.next"  =>  c.  
#Crear un  programa llamado gen.rby que contenga un método llamado gen que reciba 
#el número de letras a generar y devuelva un string con todas las letras generadas concatendas.

def gen(n_letters)
    str =""
    letter = "a"

    n_letters.times do
        str += letter
        letter = letter.next
    end
    return str
end

n_letters = ARGV[0].to_i
puts gen(n_letters)
